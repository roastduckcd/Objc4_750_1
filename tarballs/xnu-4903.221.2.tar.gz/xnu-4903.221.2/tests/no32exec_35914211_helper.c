#include <darwintest.h>

T_DECL(null_test, "nothing to see here")
{
	T_SKIP("nothing to see here");
}
