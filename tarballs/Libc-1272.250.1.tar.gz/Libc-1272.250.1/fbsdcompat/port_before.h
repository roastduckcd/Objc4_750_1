/* FreeBSD only needs this for isc, nameser and resolv */
