
int bar()
{
	return RESULT;
}
